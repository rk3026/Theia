## 0.3.48

- Add Windows support

## 0.3.47

- Add Linux support

## 0.3.46

- Plugin rework by Sergey Savchuk and Evgeniy Vabishchevich

## 0.0.1

- Initial release
